package com.faint.persistence;

import java.util.List;

import com.faint.domain.PostVO;

public interface PostDAO {
	
	public void create(PostVO vo)throws Exception;
	
	public List<PostVO> read(Integer userid) throws Exception;
	
	public void update(PostVO vo) throws Exception;
	
	public void delete(Integer id) throws Exception;
	
	public void addAttach(String fullName) throws Exception;
}
