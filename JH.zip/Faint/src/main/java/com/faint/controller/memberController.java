package com.faint.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.faint.domain.ReplyVO;
import com.faint.domain.UserVO;
import com.faint.dto.followDTO;
import com.faint.dto.loginDTO;
import com.faint.service.UserService;

@Controller
@RequestMapping("/member/*")
public class memberController {
	
	private static final Logger logger = LoggerFactory.getLogger(memberController.class);
		
	@Inject
	private UserService service;
	
	@RequestMapping(value="/profile_test", method=RequestMethod.GET)
	public void registerGET(UserVO user, Model model) throws Exception{
		logger.info("profile get................");
	}
	
	@RequestMapping(value="/profile_test", method=RequestMethod.POST)
	public void registerPOST(UserVO user, Model model) throws Exception{
		logger.info(user.toString());
		service.regist(user);
	}
	
	@RequestMapping(value="/profile_main", method=RequestMethod.GET)
	public void listAll(Model model) throws Exception{
		
		model.addAttribute("list", service.listAll());
		
	}
	
	@RequestMapping(value="/profile", method=RequestMethod.GET)
	public void read(@RequestParam("id") int id, Model model, HttpServletRequest request) throws Exception{
		model.addAttribute("userVO", service.read(id));
		
		//�α��������� ������ ���� ��
		if(request.getSession()!=null){
			HttpSession session=request.getSession();
			UserVO vo=(UserVO)session.getAttribute("login");
			
			//1�ϰ�� �ȷο� ���� ����, 0�ϰ�� �ȷο찡 �ƴѰ���, -1�� ��� ����������
			if(id!=vo.getId()){ //���ǰ��� userpage������ �ٸ���� (�ȷο� ���� Ȯ��(1�ϰ�� �ȷο� �� 0�ϰ�� �ȷο� �ƴ�))
				followDTO dto=new followDTO();
				dto.setFollowedid(id);
				dto.setUserid(vo.getId());
				model.addAttribute("relation", service.isFlw(dto));
			}else if(id==vo.getId()){ //���ǰ��� userpage������ ���� ��� - �ش��������� �������̹Ƿ� ������ �� �ִ� ���Ѻο�
				model.addAttribute("relation", -1);
			}
		};

		
	}
	
	// �ȷο� ���� ��Ʈ�ѷ�-------------------------------
	//follow ��� - rest���
	@ResponseBody
	@RequestMapping(value="/follow", method=RequestMethod.POST)
	public ResponseEntity<String> followStart(@RequestBody followDTO dto){
		ResponseEntity<String> entity=null;
		System.out.println(dto);
		try{	
			service.flwCreate(dto);
			entity=new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			entity=new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	//follow ���� - rest���
	@ResponseBody
	@RequestMapping(value="/unfollow", method=RequestMethod.DELETE)
	public ResponseEntity<String> unfollow(@RequestBody followDTO dto){
		ResponseEntity<String> entity=null;
		System.out.println(dto);
		try{
			service.flwDelete(dto);
			entity=new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			entity=new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	// �ش� ������ follow�ϴ� ��� ����Ʈ URI
	@ResponseBody
	@RequestMapping(value="/following/{userid}", method=RequestMethod.GET)
	public ResponseEntity<List<followDTO>> flwnList(@PathVariable("userid") Integer userid){
		ResponseEntity<List<followDTO>> entity=null;
		try{
			entity=new ResponseEntity<>(service.flwnList(userid), HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			entity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	// �ش� ������ follow�ϴ� ��� ����Ʈ URI
	@ResponseBody
	@RequestMapping(value="/followed/{userid}", method=RequestMethod.GET)
	public ResponseEntity<List<followDTO>> flwdList(@PathVariable("userid") Integer userid){
		ResponseEntity<List<followDTO>> entity=null;
		try{
			entity=new ResponseEntity<>(service.flwdList(userid), HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			entity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	// �ش� ������ follow�ϴ� ��� count URI
	@ResponseBody
	@RequestMapping(value="/followingCnt/{userid}", method=RequestMethod.GET)
	public ResponseEntity<Integer> flwnCnt(@PathVariable("userid") Integer userid){
		ResponseEntity<Integer> entity=null;
		try{
			entity=new ResponseEntity<Integer>(service.flwnCnt(userid), HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			entity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	// �ش� ������ follow�ϴ� ��� count URI
	@ResponseBody
	@RequestMapping(value="/followedCnt/{userid}", method=RequestMethod.GET)
	public ResponseEntity<Integer> flwdCnt(@PathVariable("userid") Integer userid){
		ResponseEntity<Integer> entity=null;
		try{
			entity=new ResponseEntity<Integer>(service.flwdCnt(userid), HttpStatus.OK);
		}catch(Exception e){
			e.printStackTrace();
			entity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return entity;
	}
	
	//�α��� ���� ��Ʈ�ѷ�======================================
	//�α��� ������
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public void loginGET(@ModelAttribute("dto") loginDTO dto){ 
		
	}
	//�α��� ����������(������ LOGIN�Ӽ��� uservo�� �߰�) - login ���ͼ��Ͱ� �۵�
	@RequestMapping(value="/loginPost", method=RequestMethod.POST)
	public void loginPOST(loginDTO dto, HttpSession session, Model model) throws Exception{
		UserVO vo=service.login(dto);
		if(vo==null){
			return;
		}
		model.addAttribute("userVO", vo);
	}
	
}
	
