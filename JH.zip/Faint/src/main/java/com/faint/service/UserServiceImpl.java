package com.faint.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.faint.domain.UserVO;
import com.faint.dto.followDTO;
import com.faint.dto.loginDTO;
import com.faint.persistence.UserDAO;

@Service
public class UserServiceImpl implements UserService{
	
	@Inject
	private UserDAO dao;
	
	@Override
	public void regist(UserVO user) throws Exception{
		dao.create(user);
	}
	
	@Override
	public UserVO read(Integer id) throws Exception{
		return dao.read(id);
	}
	
	@Override
	public void modify(UserVO user) throws Exception{
		dao.update(user);
	}
	
	@Override
	public void remove(Integer id) throws Exception{
		dao.delete(id);
	}
	
	@Override
	public List<UserVO> listAll() throws Exception{
		return dao.listAll();
	}
/*	 �ȷο� =========================================== */
	
	@Override
	public void flwCreate(followDTO dto)throws Exception{
		dao.flwCreate(dto);
	}
	
	@Override
	public void flwDelete(followDTO dto)throws Exception{
		dao.flwDelete(dto);
	}
	
	@Override
	public int isFlw(followDTO dto)throws Exception{
		return dao.isFlw(dto);
	}
	
	@Override
	public List<followDTO> flwnList(int userid) throws Exception{
		return dao.flwnList(userid);
	}
	
	@Override
	public List<followDTO> flwdList(int userid) throws Exception{
		return dao.flwdList(userid);
	}
	
	@Override
	public int flwnCnt(int userid) throws Exception{
		return dao.flwnCnt(userid);
	}
	
	@Override
	public int flwdCnt(int userid) throws Exception{
		return dao.flwdCnt(userid);
	}
	
	//�α���=======================================
	@Override
	public UserVO login(loginDTO dto)throws Exception{
		return dao.login(dto);
	}

}
