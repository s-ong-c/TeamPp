package com.faint.service;


import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.faint.domain.PostVO;
import com.faint.persistence.PostDAO;

@Service
public class PostServiceImpl implements PostService{
	
	@Inject
	private PostDAO dao;
	
	@Transactional //�� �ȵ����� �˼��� ����....... Ʈ����� ���Ƶ���.
	@Override
	public void regist(PostVO post) throws Exception {
		dao.create(post);
		
		String[] files = post.getFiles();
		
		if(files == null) {return;}
		
		for(String url : files) {
			dao.addAttach(url);
		}
	}
	
	@Override
	public List<PostVO> read(Integer userid) throws Exception{
		return dao.read(userid);
	}
	
	@Override
	public void modify(PostVO post) throws Exception{
		dao.update(post);
	}
	
	@Override
	public void remove(Integer id) throws Exception{
		dao.delete(id);
	}
	
}
