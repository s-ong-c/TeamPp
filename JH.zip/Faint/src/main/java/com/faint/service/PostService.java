package com.faint.service;

import java.util.List;

import com.faint.domain.PostVO;

public interface PostService{
	
	public void regist(PostVO post) throws Exception;
	
	public List<PostVO> read(Integer userid) throws Exception;
	
	public void modify(PostVO post) throws Exception;
	
	public void remove(Integer id) throws Exception;
	
}
