package com.faint.service;

import java.util.List;

import com.faint.domain.UserVO;
import com.faint.dto.followDTO;
import com.faint.dto.loginDTO;

public interface UserService {
	
	public void regist(UserVO user) throws Exception;
	
	public UserVO read(Integer id) throws Exception;
	
	public void modify(UserVO user) throws Exception;
	
	public void remove(Integer id) throws Exception;
	
	public List<UserVO> listAll() throws Exception;
	
	/*�ȷο�*/
	public void flwCreate(followDTO dto)throws Exception;
	
	public void flwDelete(followDTO dto)throws Exception;
	
	public int isFlw(followDTO dto)throws Exception;
	
	public List<followDTO> flwnList(int userid) throws Exception;
	
	public List<followDTO> flwdList(int userid) throws Exception;
	
	public int flwnCnt(int userid) throws Exception;
	
	public int flwdCnt(int userid) throws Exception;
	
	//�α���
	
	public UserVO login(loginDTO dto)throws Exception;
}
